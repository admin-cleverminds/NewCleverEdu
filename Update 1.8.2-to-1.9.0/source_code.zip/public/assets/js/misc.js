var ChartColor = ["#5D62B4", "#54C3BE", "#EF726F", "#F9C446", "rgb(93.0, 98.0, 180.0)", "#21B7EC", "#04BCCC"];
var primaryColor = getComputedStyle(document.body).getPropertyValue('--primary');
var secondaryColor = getComputedStyle(document.body).getPropertyValue('--secondary');
var successColor = getComputedStyle(document.body).getPropertyValue('--success');
var warningColor = getComputedStyle(document.body).getPropertyValue('--warning');
var dangerColor = getComputedStyle(document.body).getPropertyValue('--danger');
var infoColor = getComputedStyle(document.body).getPropertyValue('--info');
var darkColor = getComputedStyle(document.body).getPropertyValue('--dark');
var lightColor = getComputedStyle(document.body).getPropertyValue('--light');

(function ($) {
    'use strict';
    $(function () {
        var body = $('body');
        var contentWrapper = $('.content-wrapper');
        var scroller = $('.container-scroller');
        var footer = $('.footer');
        var sidebar = $('.sidebar');

        //Add active class to nav-link based on url dynamically
        //Active class can be hard coded directly in html file also as required

        function addActiveClass(element) {
            var current = window.location.href;
            if (current === "") {
                //for root url
                if (element.attr('href').indexOf("index.html") !== -1) {
                    element.parents('.nav-item').last().addClass('active');
                    if (element.parents('.sub-menu').length) {
                        element.closest('.collapse').addClass('show');
                        element.addClass('active');
                    }
                }
            } else {
                //for other url
                // if (element.attr('href').includes(current)) {
                if (element.attr('href') === current) {
                    element.parents('.nav-item').last().addClass('active');
                    if (element.parents('.sub-menu').length) {
                        element.closest('.collapse').addClass('show');
                        element.addClass('active');
                    }
                    if (element.parents('.submenu-item').length) {
                        element.addClass('active');
                    }
                }
            }
        }


        let lastPathName = location.pathname.split("/").slice(-1)[0].replace(/^\/|\/$/g, '');
        var current = window.location.href;
        if (['edit', 'create'].includes(lastPathName)) {
            location.pathname.split("/").slice(2).forEach(function (value, index) {
                current = current.replace("/" + value, '');
            })
        }
        $('.nav li a', sidebar).each(function () {
            var $this = $(this);
            addActiveClass($this);
        })

        $('.horizontal-menu .nav li a').each(function () {
            var $this = $(this);
            addActiveClass($this);
        })

        //Close other submenu in sidebar on opening any

        sidebar.on('show.bs.collapse', '.collapse', function () {
            sidebar.find('.collapse.show').collapse('hide');
        });


        //Change sidebar and content-wrapper height
        applyStyles();

        function applyStyles() {
            //Applying perfect scrollbar
            if (!body.hasClass("rtl")) {
                if ($('.settings-panel .tab-content .tab-pane.scroll-wrapper').length) {
                    const settingsPanelScroll = new PerfectScrollbar('.settings-panel .tab-content .tab-pane.scroll-wrapper');
                }
                if ($('.chats').length) {
                    const chatsScroll = new PerfectScrollbar('.chats');
                }
                if (body.hasClass("sidebar-fixed")) {
                    // var fixedSidebarScroll = new PerfectScrollbar('#sidebar .nav');
                }
            }
        }

        $('[data-toggle="minimize"]').on("click", function () {
            if ((body.hasClass('sidebar-toggle-display')) || (body.hasClass('sidebar-absolute'))) {
                body.toggleClass('sidebar-hidden');
            } else {
                body.toggleClass('sidebar-icon-only');
            }
        });

        //checkbox and radios
        $(".form-check label,.form-radio label").append('<i class="input-helper"></i>');

        //fullscreen
        $("#fullscreen-button").on("click", function toggleFullScreen() {
            if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)) {
                if (document.documentElement.requestFullScreen) {
                    document.documentElement.requestFullScreen();
                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();
                } else if (document.documentElement.webkitRequestFullScreen) {
                    document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
                } else if (document.documentElement.msRequestFullscreen) {
                    document.documentElement.msRequestFullscreen();
                }
            } else {
                if (document.cancelFullScreen) {
                    document.cancelFullScreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitCancelFullScreen) {
                    document.webkitCancelFullScreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
            }
        })

        // if ($.cookie('purple-pro-banner')!="true") {
        //   document.querySelector('#proBanner').classList.add('d-flex');
        //   document.querySelector('.navbar').classList.remove('fixed-top');
        // }
        // else {
        //   document.querySelector('#proBanner').classList.add('d-none');
        //   document.querySelector('.navbar').classList.add('fixed-top');
        // }

        if ($(".navbar").hasClass("fixed-top")) {
            if (document.querySelector('.page-body-wrapper')) {
                document.querySelector('.page-body-wrapper').classList.remove('pt-0');
            }
            if (document.querySelector('.navbar')) {
                document.querySelector('.navbar').classList.remove('pt-5');
            }
        } else {
            if (document.querySelector('.page-body-wrapper')) {
                document.querySelector('.page-body-wrapper').classList.add('pt-0');
            }
            if (document.querySelector('.navbar')) {
                document.querySelector('.navbar').classList.add('pt-5');
                document.querySelector('.navbar').classList.add('mt-3');
            }
        }
        // document.querySelector('#bannerClose').addEventListener('click',function() {
        //   // document.querySelector('#proBanner').classList.add('d-none');
        //   // document.querySelector('#proBanner').classList.remove('d-flex');
        //   document.querySelector('.navbar').classList.remove('pt-5');
        //   document.querySelector('.navbar').classList.add('fixed-top');
        //   // document.querySelector('.page-body-wrapper').classList.add('proBanner-padding-top');
        //   document.querySelector('.navbar').classList.remove('mt-3');
        //   var date = new Date();
        //   date.setTime(date.getTime() + 24 * 60 * 60 * 1000);
        //   $.cookie('purple-pro-banner', "true", { expires: date });
        // });

        // if ($(".select2").length) {
        //     $(".select2").select2();
        // }
    });
})(jQuery);
